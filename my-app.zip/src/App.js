import logo from './logo.svg';
import './App.css';
import UserList from './component/UserList';
import './index.css';
function App() {
  return (
    <div className="App">
      <UserList></UserList>
    </div>
  );
}

export default App;
